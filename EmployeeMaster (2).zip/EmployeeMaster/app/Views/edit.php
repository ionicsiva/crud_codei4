
<div class="container">
	<h1 style="color:#043b76;">Edit The Employee</h1>
</div>
<div class="container">
	 <form action="<?= base_url('update/' .$employees['EMPLOYEE_ID']); ?>" id="validate" name="update_product" method="post" >
		<div class="card card-warning">
			<div class="card-header">
				<h2 class="card-title">Add Student</h2>


			</div>
			<div class="card-body">
				<div class="container">
					<div class="row">
						<div class="col-12 form-group">
							<label  class="form-label">Employee Name</label>
							<input  value="<?php echo $employees['EMPLOYEE_NAME']; ?>" type="text" placeholder="Enter Employee Name"class="form-control" name="EMPLOYEE_NAME">
						</div>

						<div class="col-6 form-group">
							<label  class="form-label">Date Of Birth</label>
							<input   type="date" value="<?php echo $employees['DOB']; ?>" placeholder="Enter Date of Birth"class="form-control"  name="DOB">
						</div>
						<div class="col-6 form-group">
							<label  class="form-label">Attendance</label>
							<input  value="<?php echo $employees['ATTENDANCE']; ?>"  placeholder="Enter Attendance"class="form-control" name="ATTENDANCE">
						</div>


						<div class="col-12 form-group">
							<label  class="form-label">Address</label>
							<input  value="<?php echo $employees['ADDRESS']; ?>"  placeholder="Enter Address"class="form-control" name="ADDRESS">
						</div>
						
						<div class="col-12 form-group">
							<label  class="form-label">Type</label>
							<input  value="<?php echo $employees['TYPE']; ?>"  placeholder="Enter Type"class="form-control" name="TYPE">
						</div>
						

					</div>

				</div>
			</div>
			<div class="card-footer">
				<button type="submit" class="btn btn-warning">Update</button>


			</div>
		</div>
	</form>
</div>
