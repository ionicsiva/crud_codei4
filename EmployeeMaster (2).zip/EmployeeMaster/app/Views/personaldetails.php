<!-- attendance.php -->
<div class="wrapper">
    <div class="title_index">
        <h1 style="color:#007089">Personal Details</h1>
    </div>
    <!-- Filter dropdown -->
    <div class="filter m-4">
    <label>Filter by Type:</label>
    <div class="checkbox-list">
        <div class="checkbox-item row-type">
            <input type="checkbox" id="fresher" value="fresher">
            <label for="fresher">Fresher</label>
        </div>
        <div class="checkbox-item row-type">
            <input type="checkbox" id="experienced" value="experienced">
            <label for="experienced">Experienced</label>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('.checkbox-list input[type="checkbox"]').change(function(){
            var selectedTypes = [];
            $('.checkbox-list input[type="checkbox"]:checked').each(function(){
                selectedTypes.push($(this).val());
            });
            if(selectedTypes.length === 0 || selectedTypes.includes('all')) {
                $('.employee-row').show();
            } else {
                $('.employee-row').hide();
                selectedTypes.forEach(function(type) {
                    $('.employee-row').filter(function(){
                        return $(this).find('td:eq(3)').text() == type;
                    }).show();
                });
            }
        });
    });
</script>


    <div class="table_space">
        <table class="table table-striped table-bordered" id="employeeTable">
            <thead class="table-warning">
                <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Employee Name</th>
                    <th class="text-center">DOB</th>
                    <th class="text-center">TYPE</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($employee): ?>
                    <?php $n = 1; ?>
                    <?php foreach ($employee as $employee): ?>
                        <tr class="employee-row">
                            <td class="text-center"><?php echo $n++; ?></td>
                            <td class="text-center"><?php echo $employee['EMPLOYEE_NAME']; ?></td>
                            <td class="text-center"><?php echo $employee['DOB']; ?></td>
                            <td class="text-center"><?php echo $employee['TYPE']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
