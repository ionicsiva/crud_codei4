<script src="<?php echo base_url(); ?>assets/dist/js/script.js"></script>


</body>
</html>