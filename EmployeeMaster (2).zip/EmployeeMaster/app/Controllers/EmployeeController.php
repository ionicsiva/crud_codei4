<?php

namespace App\Controllers;
use \App\Models\EmployeeModel;

class EmployeeController extends BaseController
{
    public function index()
    {   
    	$model = new EmployeeModel;
    	$data['employees'] = $model->orderby('EMPLOYEE_ID','ASC')->findAll();
    	echo view('partials/header');
        echo view('list.php',$data);
        echo view('partials/footer');
        
    }
    
      public function delete($ID = null)
    {
        $model = new EmployeeModel; 
        $delete = $model->delete($ID);

        if ($delete) {
            session()->setFlashdata('success', 'Page deleted successfully.');
        } else {
            session()->setFlashdata('danger', 'Failed to delete Page .');
        }

        return redirect()->to(site_url('/list'));
    }


    public function view($ID = null){

    
        $model = new EmployeeModel();
        $data['employees'] = $model->find($ID);
       	echo view('partials/header');
        echo view('view.php',$data);
        echo view('partials/footer');

        return;
        
        
    
}

  public function edit($ID = null){

    
        $model = new EmployeeModel();
        $data['employees'] = $model->find($ID);
       	echo view('partials/header');
        echo view('edit.php',$data);
        echo view('partials/footer');

        return; 
}

public function update($ID)
{
    $model = new EmployeeModel();
    $employee = $model->find($ID);
    if ($employee) {
        // Get the current month and year
        $currentMonth = date('m');
        $currentYear = date('Y');
        
        // Calculate the total working days based on the current month
        $totalWorkingDays = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);
        
        // Calculate the attendance percentage
        $attendance = $this->request->getVar('ATTENDANCE');
        $attendancePercentage = ($attendance / $totalWorkingDays) * 100;
        
        // Assuming salary is fixed at 10k
        $totalSalary = 10000 * $attendancePercentage / 100; 
        
        // Retrieve the updated data from the form
        $data = [
            'EMPLOYEE_NAME' => $this->request->getVar('EMPLOYEE_NAME'),
            'DOB' => $this->request->getVar('DOB'),
            'ADDRESS' => $this->request->getVar('ADDRESS'),
            'ATTENDANCE' => $attendance,
            'TYPE' => $this->request->getVar('TYPE'),
            'SALARY' => $totalSalary,
        ];
        
        $model->update($ID, $data);
        
        return redirect()->to(site_url('/list'));
    } else {
        return "Employee not found.";
    }
}



public function add()
    {
        $validation = \Config\Services::validation();
        $model = new EmployeeModel;
        
        echo view('partials/header');
        echo view('add.php');
        echo view('partials/footer');
    }


    public function store()
    {
        $model = new EmployeeModel();
        $attendance = $this->request->getVar('ATTENDANCE');
        
        $currentMonth = date('m');
        $currentYear = date('Y');
        
        $totalWorkingDays = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);
        
        $attendancePercentage = ($attendance / $totalWorkingDays) * 100;
        
        $totalSalary = 10000 * $attendancePercentage / 100; 
        $data = [
            'EMPLOYEE_NAME' => $this->request->getVar('EMPLOYEE_NAME'),
            'SALARY' => $totalSalary,
            'ADDRESS' => $this->request->getVar('ADDRESS'),
            'TYPE' =>$this->request->getVar('TYPE'),
            'DOB' => $this->request->getVar('DOB'),
            'ATTENDANCE' => $attendance,
            'ATTENDANCE_PERCENTAGE' => $attendancePercentage // Storing attendance percentage
        ];
        
        $save = $model->insert($data);
        return redirect()->to(site_url('/list'));
    }
      

public function attendanceData()
{
    $model = new EmployeeModel();
    $data['attendances'] = $model->findAll(); 
    echo view('partials/header');
    echo view('attendance', $data);
    echo view('partials/footer');
}

public function personal()
{
    $model = new EmployeeModel();
    $data['employee'] = $model->findAll(); 
    echo view('partials/header');
    echo view('personaldetails', $data);
    echo view('partials/footer');
}


}


        