
<div class="container">
	<h1 style="color:#043b76;">Employee</h1>
</div>
<div class="container">
	
		<div class="card card-primary">
			<div class="card-header">
				<h2 class="card-title">Employee Details</h2>


			</div>
			<div class="card-body">
				<div class="container">
					<div class="row">
						<div class="col-12 form-group">
							<label  class="form-label">Employee Name</label>
							<input readonly value="<?php echo $employees['EMPLOYEE_NAME']; ?>" type="text" placeholder="Enter Employee Name"class="form-control" name="NAME">
						</div>

						<div class="col-6 form-group">
							<label  class="form-label">Date Of Birth</label>
							<input  readonly value="<?php echo $employees['DOB']; ?>" placeholder="Enter Date of Birth"class="form-control" max="2019-12-31" name="DOB">
						</div>
						<div class="col-6 form-group">
							<label  class="form-label">Salary</label>
							<input readonly value="<?php echo $employees['SALARY']; ?>"  placeholder="Enter Salary"class="form-control" name="SCIENCE">
						</div>


						<div class="col-12 form-group">
							<label  class="form-label">Address</label>
							<input readonly value="<?php echo $employees['ADDRESS']; ?>"  placeholder="Enter Address"class="form-control" name="ENGLISH">
						
						</div>
						
						
						

					</div>

				</div>
			</div>
			<div class="card-footer">
				<a href="<?php echo base_url(); ?>list"><button  class="btn btn-primary">Back</button></a>


			</div>
		</div>
</div>
