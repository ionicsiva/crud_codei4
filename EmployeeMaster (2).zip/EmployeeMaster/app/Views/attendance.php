<!-- attendance.php -->
<div class="wrapper">
    <div class="title_index">
        <h1 style="color:#007089">Attendance</h1>
    </div>
    <div class="table_space">
        <table class="table table-striped table-bordered">
            <thead class="table-danger">
                <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Employee Name</th>
                    <th class="text-center">Salary</th>
                    <th class="text-center">Attendance</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($attendances): ?>
                    <?php $n = 1; ?>
                    <?php foreach ($attendances as $attendance): ?>
                        <tr>
                            <td class="text-center"><?php echo $n++; ?></td>
                            <td class="text-center"><?php echo $attendance['EMPLOYEE_NAME']; ?></td>
                            <td class="text-center"><?php echo $attendance['SALARY']; ?></td>
                            <td class="text-center"><?php echo $attendance['ATTENDANCE']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
